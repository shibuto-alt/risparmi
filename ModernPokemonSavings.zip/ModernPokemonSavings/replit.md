# Sistema Avanzato Gestione Risparmi e Investimenti

## Overview

This is an advanced Italian savings and investment management system built as a single-page web application. The system provides comprehensive financial tracking capabilities including savings management, investment portfolio analysis, and financial visualization through interactive charts. The application features a modern, responsive interface with tabbed navigation and uses Chart.js for data visualization. It appears to be designed for personal finance management with a focus on Italian users, offering tools to track savings goals, investment performance, and financial progress over time.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Built using vanilla HTML, CSS, and JavaScript without any framework dependencies
- **Component-Based UI**: Utilizes a tabbed interface system for different functional areas (savings, investments, analytics)
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox layouts
- **Modern CSS**: Uses CSS custom properties (variables) for consistent theming and design system
- **Chart Integration**: Chart.js library for interactive financial data visualization

### Data Management
- **Client-Side Storage**: All data is stored locally in the browser using localStorage
- **JSON-Based Data Structure**: Financial data is serialized and stored as JSON objects
- **Real-Time Updates**: Interface updates dynamically as users input financial data
- **No Backend Dependencies**: Completely self-contained frontend application

### Styling and Design System
- **CSS Custom Properties**: Comprehensive design token system with predefined color schemes, shadows, and spacing
- **Inter Font**: Google Fonts integration for modern typography
- **Gradient Backgrounds**: Linear gradients for visual appeal and modern aesthetic
- **Card-Based Layout**: Content organized in card components with consistent shadows and borders
- **Color-Coded Elements**: Different colors for various financial categories (primary, secondary, warning, danger)

### User Experience
- **Tabbed Navigation**: Multi-section interface allowing users to switch between different financial views
- **Interactive Charts**: Real-time chart updates based on financial data input
- **Form-Based Input**: Structured forms for entering savings goals, investment data, and financial transactions
- **Visual Feedback**: Immediate visual updates and feedback for user actions

## External Dependencies

### CDN Libraries
- **Chart.js (v3.9.1)**: JavaScript charting library for creating interactive financial charts and graphs
- **Google Fonts**: Inter font family for modern, clean typography

### Browser APIs
- **localStorage**: For persistent client-side data storage
- **DOM APIs**: For dynamic interface updates and user interaction handling
- **CSS Grid/Flexbox**: For responsive layout management

### No Server Dependencies
- **Static Hosting**: Application can be served from any static file server
- **No Database**: All data persistence handled through browser localStorage
- **No Authentication**: Single-user application without user management system